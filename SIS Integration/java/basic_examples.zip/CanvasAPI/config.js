{ access_token:"",
account_id:"",
domain:"cwt.test",
import_file:"/path/to/import_file.zip",
filetype:"zip"
}
